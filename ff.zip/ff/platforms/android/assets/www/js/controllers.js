angular.module('starter.controllers', [])

.controller('AppCtrl', function($scope, $ionicModal, $timeout,$ionicLoading) {

 $ionicLoading.show({
	template: '<ion-spinner  icon="ripple"></ion-spinner>',	 
     duration: 3000,
  });
  
})

.controller('LoginCtrl', function($scope, $state, $templateCache, $q, $rootScope, $timeout,$ionicLoading) {
	 $ionicLoading.show({
	template: '<ion-spinner  icon="ripple"></ion-spinner>',	 
     duration: 3000,
  });
  	$scope.user = {};

	$scope.user.Email = "prakash@gyso.co.in";
	$scope.user.Password = "tien1994";
	
	$scope.doLogin = function() {
		$state.go('app.profile');		
		console.log('Doing login Datas:', $scope.user);
		console.log($scope.user.Email);
		
	// Save data to the current local store
	localStorage.setItem("UserName", $scope.user.Email);
	localStorage.setItem("UserPassword", $scope.user.Password);

	// Access some stored data
	alert( "UserName = " + localStorage.getItem("UserName"));	
	alert( "Password = " + localStorage.getItem("UserPassword"));		

		sessionStorage.setItem('UserName', $scope.user.Email);
		sessionStorage.setItem('Password',  $scope.user.Password);
		
	var post = {
	  UserName: $scope.user.Email,
	  UserPassword: $scope.user.Password
	};

	window.localStorage['post'] = JSON.stringify(post);

	var post = JSON.parse(window.localStorage['post'] || '{}');
	
};

})

.controller('SignupCtrl', function($scope,$http, $state, $timeout,$ionicLoading) {
	 $ionicLoading.show({
	template: '<ion-spinner  icon="ripple"></ion-spinner>',	 
     duration: 3000,
  });
  
	$scope.user = {};

	$scope.user.Name = "TienPrakash";
	$scope.user.Email = "prakash@gyso.co.in";
	$scope.user.Password = "tien1994";
	$scope.user.Conform_Password = "tien1994";

	  $scope.doRegister = function() {
		$state.go('app.profile');	
		console.log('Doing register Datas:', $scope.user);
		
		console.log($scope.user);


		var posting = $http({			
			method : 'POST',
			url    : 'http://localhost:8101/signup.php',			
			data: $scope.user 
		})	
	  };
})

/* .controller('ForgotPasswordCtrl', function($scope, $state) {
	$scope.recoverPassword = function(){
		$state.go('app.profile');
	};

	$scope.user = {};
})
 */
.controller('locationCtrl', function($scope,$ionicModal,$http, $timeout,$ionicLoading) {
 $ionicLoading.show({
	template: '<ion-spinner  icon="ripple"></ion-spinner>',	 
     duration: 3000,
  });



})
.controller('indiaCtrl', function($scope,$ionicModal,$http, $timeout,$ionicLoading,$ionicScrollDelegate) {
	$ionicLoading.show({
	template: '<ion-spinner  icon="ripple"></ion-spinner>',	 
     duration: 3000,
  });
  	$http.get("cities.json").then(function(data){
		var cities = data.data.results;
		$scope.cities = data.data.results;
	})
	
/* 
     $scope._list = [];
     var from = 1;
     var last = '$last';
     $scope.populateList = function() {
         populateLists();
     }
     $scope.canWeLoadMoreContent = function() {
         return ($scope._list.length > last) ? false : true;
     }
     populateLists();

     function populateLists() {
         $http.get('cities.json').success(function(data) {
             $scope.list = data.results;
             var limit = from + 30;
             for (var i = from; i <= limit; i++) {
                 console.log($scope.list[i]);
                 $scope._list.push({
                     id: $scope.list[i].id,
                     name: $scope.list[i].name,
                     state: $scope.list[i].state
                 });
                 from = i;
             }
             $scope.$broadcast('scroll.infiniteScrollComplete');
         });
     } */
	  $scope.scrollTop = function() {
    $ionicScrollDelegate.scrollTop();
  }; 

  
})
.controller('indiadetailCtrl', function($scope,$ionicModal,$http, $filter,$stateParams, $timeout,$ionicLoading) {
 $ionicLoading.show({
	template: '<ion-spinner  icon="ripple"></ion-spinner>',	 
     duration: 3000,
  });
  
	$http.get("cities.json").then(function(data){
		var cities = data.data;
		
	$scope.id = $stateParams.indiadetailid;	
	console.log($scope.id );
	
	  var result = $filter('filter')(cities.results, {id:$scope.id})[0];
	  $scope.name = result.name;
	  $scope.state = result.state;
	  console.log($scope.name);
});
})

.controller('countriesCtrl', function($scope,$ionicModal,$http, $timeout,$ionicLoading,$ionicScrollDelegate) {
 $ionicLoading.show({
	template: '<ion-spinner  icon="ripple"></ion-spinner>',	 
     duration: 3000,
  });
  
	$http.get("countries.json").then(function(data){
		$scope.countries = data.data.results;
	})
	  $scope.scrollTop = function() {
    $ionicScrollDelegate.scrollTop();
  }; 

  
})
.controller('countriesdetailCtrl', function($scope,$http, $filter,$stateParams, $timeout,$ionicLoading) {
 $ionicLoading.show({
	template: '<ion-spinner  icon="ripple"></ion-spinner>',	 
     duration: 3000,
  });

	$http.get("countries.json").then(function(data){
		var country = data.data;
		console.log(country);
		

	  
	$scope.id = $stateParams.countrycca2;	
	console.log($scope.id);
	
	  var result = $filter('filter')(country.results, {cca2:$scope.id})[0];
	  $scope.countryname = result.name.common;
	  $scope.countryofficial = result.name.official;
	  $scope.countrynative = result.name.native;
	  $scope.countrycurrency = result.currency;
	  $scope.countrycallingCode = result.callingCode;
	  $scope.countrycapital = result.capital;
	  $scope.countryregion = result.region;
	  $scope.countrysubregion = result.subregion;
	  $scope.countrylanguages = result.languages;
	  console.log($scope.countrylanguages);	  
	  $scope.countrytranslations = result.translations;
	  $scope.countrylatlng = result.latlng;
	  $scope.countrydemonym = result.demonym;
	  $scope.countryborders = result.borders;
	  $scope.countryarea = result.area;
	  console.log($scope.countryname);
});
})

.controller('locationpathCtrl', function($scope,$http,$stateParams, $timeout,$ionicLoading) {
 $ionicLoading.show({
	template: '<ion-spinner  icon="ripple"></ion-spinner>',	 
     duration: 3000,
  });
  
	$scope.id = $stateParams.locationpathid;	
	console.log($scope.id );
	
})


.controller('DataCtrl', function($scope,$ionicLoading) {
	 $ionicLoading.show({
	template: '<ion-spinner  icon="ripple"></ion-spinner>',	 
     duration: 3000,
  });
  
})

.controller('siteCtrl', function($scope,$ionicLoading,$http) {
	 $ionicLoading.show({
	template: '<ion-spinner  icon="ripple"></ion-spinner>',	 
     duration: 3000,
  });
  
    $http.get("sites.json").then(function(data){
		$scope.sites = data.data.sites;
		console.log($scope.sites);
	})
  
})

.controller('sitepageCtrl', function($scope,$http, $filter,$stateParams,$sce, $timeout,$ionicLoading) {
	 $ionicLoading.show({
	template: '<ion-spinner  icon="ripple"></ion-spinner>',	 
     duration: 3000,
  });
      $http.get("sites.json").then(function(data){
	  $scope.trustSrc = function(src) {
		return $sce.trustAsResourceUrl(src);
	  }	
		var sites = data.data;
		$scope.sites = data.data.sites;
		console.log($scope.sites);

  	$scope.id = $stateParams.sitepageid;	
	console.log($scope.id);
	
	var result = $filter('filter')(sites.sites, {id:$scope.id})[0];
	$scope.url = result.url;
	console.log($scope.url);
})  
  
})


.controller('galleryCtrl', function($scope,$ionicModal,$location,homeservice,$http, $timeout,$ionicLoading) {
 $ionicLoading.show({
	template: '<ion-spinner  icon="ripple"></ion-spinner>',	 
     duration: 3000,
  });
  
  	$http.get("image.json").then(function(data){
		var country = data.data;
		console.log(country);
	})
		
  	$scope.getTimes=function(n){
		 return new Array(n);
	};
	
	
  $scope.items = [];

 $scope.noMoreItemsAvailable = false;
  
  $scope.loadMore = function() {
    $scope.items.push({ id: $scope.items.length});
   
    if ( $scope.items.length == 99 ) {
      $scope.noMoreItemsAvailable = true;
    }
    $scope.$broadcast('scroll.infiniteScrollComplete');
  };
  
  $scope.items = [];
  
  
  $scope.showImages = function(index) {
    $scope.activeSlide = index;
    $scope.showModal('templates/image-popover.html');
  }
  $scope.showModal = function(templateUrl) {
    $ionicModal.fromTemplateUrl(templateUrl, {
      scope: $scope,
      animation: 'slide-in-up'
    }).then(function(modal) {
      $scope.modal = modal;
      $scope.modal.show();
    });
  }	
    // Close the modal
  $scope.closeModal = function() {
    $scope.modal.hide();
    $scope.modal.remove()
  }; 

	  
})
.controller('gameCtrl', function($scope,$ionicModal,$location,homeservice,$http, $timeout,$ionicLoading) {
 $ionicLoading.show({
	template: '<ion-spinner  icon="ripple"></ion-spinner>',	 
     duration: 3000,
  });
  
  	$http.get("image.json").then(function(data){
		$scope.games = data.data.top;
		console.log($scope.games);
	})
})
.controller('gamedetailCtrl', function($scope,$ionicModal,$filter,$stateParams,$location,homeservice,$http, $timeout,$ionicLoading) {
 $ionicLoading.show({
	template: '<ion-spinner  icon="ripple"></ion-spinner>',	 
     duration: 3000,
  });
  
  	$http.get("image.json").then(function(data){
		var games = data.data.top;
		console.log(games);  
		
	  var id = $stateParams.gamedetailviewers;
	  $scope.id = id ; 
	  console.log(id);
  
	  var result = $filter('filter')(games, {viewers:$scope.id})[0];
	  $scope.logo = result.game.logo.large;
	  console.log($scope.logo);	  
	  $scope.image = result.game.box.large;
	  console.log($scope.image);
	  $scope.name = result.game.name;
	  console.log($scope.name);	  	  
	  
	  	
  $ionicModal.fromTemplateUrl('templates/modal.html', {
    scope: $scope
  }).then(function(modal) {
    $scope.modal = modal;
  });
  
  $scope.openModal = function() {
    $scope.modal.show()
	  $scope.image = result.image;
	console.log($scope.image);
  }
});
});