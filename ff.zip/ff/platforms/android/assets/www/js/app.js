// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
// 'starter.controllers' is found in controllers.js
angular.module('starter', ['ionic', 'starter.controllers','starter.services','ngSanitize'])

.run(function($ionicPlatform) {
  $ionicPlatform.ready(function() {
    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
    // for form inputs)
    if (window.cordova && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
      cordova.plugins.Keyboard.disableScroll(true);

    }
    if (window.StatusBar) {
      // org.apache.cordova.statusbar required
      StatusBar.styleDefault();
    }
  });
})

.config(function($stateProvider, $urlRouterProvider) {
  $stateProvider

    .state('app', {
    url: '/app',
    abstract: true,
    templateUrl: 'templates/menu.html',
    controller: 'AppCtrl'
  })
  
  .state('app.home', {
    url: '/home',
    views: {
      'menuContent': {
        templateUrl: 'templates/home.html',
		controller: 'AppCtrl'
      }
    }
  })
  .state('app.profile', {
    url: '/profile',
    views: {
      'menuContent': {
        templateUrl: 'templates/profile.html',
		controller: 'AppCtrl'
		
      }
    }
  })

    .state('app.location', {
      url: '/location',
      views: {
        'menuContent': {
          templateUrl: 'templates/location.html',
        controller: 'locationCtrl'		  
        }
      }
    })
    .state('app.countries', {
      url: '/countries',
      views: {
        'menuContent': {
          templateUrl: 'templates/countries.html',
        controller: 'countriesCtrl'		  
        }
      }
    })
	.state('app.site', {
      url: '/site',
      views: {
        'menuContent': {
          templateUrl: 'templates/site.html',
        controller: 'siteCtrl'		  
        }
      }
    })
	.state('app.countriesdetail', {
      url: '/countriesdetail/:countrycca2',
      views: {
        'menuContent': {
          templateUrl: 'templates/countriesdetail.html',
        controller: 'countriesdetailCtrl'		  
        }
      }
    })
	.state('app.sitepage', {
      url: '/sitepage/:sitepageid',
      views: {
        'menuContent': {
          templateUrl: 'templates/sitepage.html',
        controller: 'sitepageCtrl'		  
        }
      }
    })	
    .state('app.india', {
      url: '/india',
      views: {
        'menuContent': {
          templateUrl: 'templates/india.html',
        controller: 'indiaCtrl'		  
        }
      }
    })
    .state('app.game', {
      url: '/game',
      views: {
        'menuContent': {
          templateUrl: 'templates/game.html',
        controller: 'gameCtrl'		  
        }
      }
    })
	.state('app.gamedetail', {
      url: '/gamedetail/:gamedetailviewers',
      views: {
        'menuContent': {
          templateUrl: 'templates/gamedetail.html',
        controller: 'gamedetailCtrl'		  
        }
      }
    })	
    .state('app.indiadetail', {
      url: '/indiadetail/:indiadetailid',
      views: {
        'menuContent': {
          templateUrl: 'templates/indiadetail.html',
        controller: 'indiadetailCtrl'		  
        }
      }
    })	
  .state('app.gallery', {
      url: '/gallery',
      views: {
        'menuContent': {
          templateUrl: 'templates/gallery.html',
        controller: 'galleryCtrl'		  
        }
      }
    })

  
  .state('app.login', {
    url: '/login',
    views: {
      'menuContent': {
        templateUrl: 'templates/login.html',
		controller: 'LoginCtrl'
      }
    }
  })
  
    .state('app.register', {
    url: '/register',
    views: {
      'menuContent': {
        templateUrl: 'templates/register.html',
		controller: 'SignupCtrl'
      }
    }
  })
/*   .state('app.forgot-password', {
    url: "/forgot-password",
    templateUrl: "templates/forgot-password.html",
    controller: 'ForgotPasswordCtrl'
  }) */;
  // if none of the above states are matched, use this as the fallback
  $urlRouterProvider.otherwise('/app/home');
});
