angular.module('starter.services', [])
    .factory('homeservice', ['$http','$rootScope', function($http,$rootScope) {

       var obj={};
	   
	    $rootScope.$on('gcm-register', function(event,gcmid){
	  
	   
	    
					  var name='test';
					  var email='test@poorvika.com'

	$http.post('http://app.poorvikamobile.com/index.php?route=app/register',{ 'email':email,'name':name,'regid':gcmid}
                    ).success(function(data) {
					var error = data.error;
					console.log(data);
						if(data.success){
					        $scope.mailthisspec.hide();
						}
						
                    }).error(function(data, status) {
					 return data;
                        $scope.errors.push(status);
                    });
		  
	   
	   
	   });


		obj.getbanners = function() {
			return $http.get('http://app.poorvikamobile.com/index.php?route=feed/rest_api/slidewidget',{
			  cache: true 
			});
		}
		
		 
		obj.getfeatured = function() {
			return $http.get('http://aachifoods.com/app/index.php?route=feed/rest_api/homewidgets',{
			  cache: false
			});
		}
		
		obj.checkuser=function(){
		$http.get('http://app.poorvikamobile.com/index.php?route=rest/login/checkuser').then(function(data){
			  if(data.data.success){
				window.localStorage['login-success'] = true;
			  }else{
				window.localStorage['login-success'] = false;
				 return $rootScope.$broadcast('show:login');
			  }
			   });
		}
		
		obj.getcountries=function(){
		return $http.get('countries.json',{
			  cache: true
			   });
		}

		obj.getzone=function(id){
		return $http.get('http://app.poorvikamobile.com/index.php?route=feed/rest_api/countries&id='+id,{
			  cache: false
			   });
		}
		return obj;
    }])
	
	.factory('showroom',['$http','$rootScope', function($http,$rootScope){
	var obj={};
	
	obj.getshowroomall = function() {
				return $http.get('http://app.poorvikamobile.com/index.php?route=rest/showroomlist/showroom&location_id=1');
		}
	
	
		obj.getshowroomstate = function() {
				return $http.get('http://app.poorvikamobile.com/index.php?route=rest/showroom/state');
		}
		obj.getshowroomcity = function(stateid) {
				return $http.get('http://app.poorvikamobile.com/index.php?route=rest/showroom/state&state_id='+stateid);
		}
			obj.getshowroomarea = function(areaid) {
			var stid=window.localStorage['stateid'];
				return $http.get('http://app.poorvikamobile.com/index.php?route=rest/showroom/state&state_id='+stid+'&city_id='+areaid);
		}
		
		obj.getshowroomdetails = function(showroomid) {
			var stid=window.localStorage['stateid'];
			var arid=window.localStorage['areaid'];
				return $http.get('http://app.poorvikamobile.com/index.php?route=rest/showroom/state&state_id='+stid+'&city_id='+arid+'&area_id='+showroomid);
		}	
		
		obj.getshowroomalldetails = function(showroomallid) {
			
				return $http.get('http://app.poorvikamobile.com/index.php?route=rest/showroom/state&area_id='+showroomallid);
		}
	
		
	
		return obj;
	
	}])
	
	
		.factory('service',['$http','$rootScope', function($http,$rootScope){
	var obj={};
			obj.getbrand=function(){
			
			return $http.get('http://app.poorvikamobile.com/index.php?route=rest/servicecenter/brand',{cache: false});
			}
			
			obj.getzone=function(brandid){
			
			return $http.get('http://app.poorvikamobile.com/index.php?route=rest/servicecenter/brand&brand_id='+brandid,{cache: false});
			
			}
			obj.getregion=function(zoneid){
			var bdid=window.localStorage['brandid'];
			return $http.get('http://app.poorvikamobile.com/index.php?route=rest/servicecenter/brand&brand_id='+bdid+'&zone_id='+zoneid,{cache: false});
			
			}
			
				
			obj.getarea=function(regionid,regionname){
			var bdid=window.localStorage['brandid'];
					
			return $http.get('http://app.poorvikamobile.com/index.php?route=rest/servicecenter/brand&brand_id='+bdid+'&region_id='+regionid+'&region='+regionname,{cache: false});
			
			}
			
			obj.getnearservice=function(areaid){
			var bdid=window.localStorage['brandid'];
			var reid=window.localStorage['regionid'];
			var regname=window.localStorage['regionname'];
			return $http.get('http://app.poorvikamobile.com/index.php?route=rest/servicecenter/brand&brand_id='+bdid+'&region_id='+reid+'&region='+regname+'&area_id='+areaid,{cache: false});
			
			}
			obj.getservicedetail=function(serviceid){
			var bdid=window.localStorage['brandid'];
			var reid=window.localStorage['regionid'];
			var arid=window.localStorage['areaid'];
			var regname=window.localStorage['regionname'];
			return $http.get('http://app.poorvikamobile.com/index.php?route=rest/servicecenter/brand&brand_id='+bdid+'&region_id='+reid+'&region='+regname+'&area_id='+arid+'&serviceid='+serviceid,{cache: false});
			
			}
	
	
		return obj;
	
	}])
	
	
	.factory('categories', ['$http','$rootScope', function($http,$rootScope) {
		var obj={};

		obj.getcategories = function() {
			return $http.get('http://app.poorvikamobile.com/index.php?route=feed/rest_api/categories&level=2', {
			  cache: false
				});
		}
		obj.getcategory = function(id) {
			return $http.get('http://app.poorvikamobile.com/index.php?route=feed/rest_api/category&id='+id, {
		  cache: false
			});
		}
		
		obj.getfilter = function(id) {
			return $http.get('http://app.poorvikamobile.com/index.php?route=feed/rest_api/getfilter&category_id='+id, {
		  cache: false
			});
		}
		
		return obj;
    }])
	
	.factory('product', ['$http','$rootScope', function($http,$rootScope) {
		var obj={};

		obj.getproduct = function(id) {
			return $http.get('http://app.poorvikamobile.com/index.php?route=feed/rest_api/products&id='+id, {
			  cache: false
				});
		}
		
		obj.getspecialoffers = function() {
			return $http.get('http://www.app.poorvikamobile.com/index.php?route=feed/rest_api/getspecial', {
			  cache: false
				});
		}
		
		obj.getproducts = function() {
			return $http.get('http://app.poorvikamobile.com/index.php?route=feed/rest_api/search', {
			  cache: false
				});
		}
		
		obj.search = function(data){
			return $http.post('http://app.poorvikamobile.com/index.php?route=feed/rest_api/search', data,{
			  cache: true
				});
		}
		
		obj.cartadd = function(id,qty) {
		console.log(id + qty);
			return $http.get('http://app.poorvikamobile.com/index.php?route=feed/rest_api/cart_add&product_id='+id+'&quantity='+qty);
		}
		
		
		return obj;
    }])
	
	.factory('combo', ['$http','$rootScope', function($http,$rootScope) {
		var obj={};

		obj.getcombo = function() {
			return $http.get('http://app.poorvikamobile.com/index.php?route=feed/rest_api/combo', {
			  cache: true
				});
		}
		
		return obj;
    }])
	
	.factory('cart', ['$http','$rootScope', function($http,$rootScope) {
		var obj={};

		obj.getcart = function() {
			return $http.get('http://app.poorvikamobile.com/index.php?route=rest/cart/cart');
		}
		
		obj.removeproduct = function(id) {
			return $http.delete('http://app.poorvikamobile.com/index.php?route=feed/rest_api/cart/cart',{"product_id": id});
		}
		
		return obj;
    }])
	
	.factory('checkout', ['$http','$rootScope', function($http,$rootScope) {
		var obj={};

		obj.saddress = function() {
			return $http.get('http://app.poorvikamobile.com/index.php?route=rest/shipping_address/shippingaddress');
		}
		obj.paddress = function() {
			return $http.get('http://app.poorvikamobile.com/index.php?route=rest/payment_address/paymentaddress');
		}
		
		obj.smethod = function() {
			return $http.get('http://app.poorvikamobile.com/index.php?route=rest/shipping_method/shippingmethods');
		}
		
		obj.pmethod = function() {
			return $http.get('http://app.poorvikamobile.com/index.php?route=rest/payment_method/payments');
		}
		obj.getorderinfo = function(id) {
				return $http.get('http://app.poorvikamobile.com/index.php?route=feed/rest_api/orders&id='+id);
		}
	
		
		return obj;
    }])
	
	.factory('comboinfo', ['$http','$rootScope', function($http,$rootScope) {
		var obj={};

		obj.getcomboinfo = function(id) {
			return $http.get('http://app.poorvikamobile.com/index.php?route=feed/rest_api/comboinfo&id='+id, {
			  cache: true
				});
		}
		// obj.addtocombo = function(id,qty,formdata) {
			// return $http.get('http://app.poorvikamobile.com/index.php?route=feed/rest_api_new/comboadd&id='+id+'&qty='+qty, {
			  // cache: true
				// });
		// }
		
		return obj;
    }])
	
	.factory('login', ['$http','$rootScope', function($http,$rootScope) {
		var obj={};

		obj.getlogin = function(email,password) {
				console.log(email + password);
				 $http.post('http://app.poorvikamobile.com/index.php?route=feed/rest_api/login', {'password': password, 'email': email}
                    ).success(function(data, status, headers, config) {
                        return data;
                    }).error(function(data, status) {
					 return data;
                        $scope.errors.push(status);
                    });
		}
		

				
		return obj;
    }])
	
	.factory('account', ['$http','$rootScope', function($http,$rootScope) {
		var obj={};

		obj.getaccount = function() {
				return $http.get('http://app.poorvikamobile.com/index.php?route=rest/account/getaccount');
		}
		
		obj.getwishlist = function() {
				return $http.get('http://app.poorvikamobile.com/index.php?route=rest/wishlist/wishlist');
		}
		
		obj.getorder = function(id) {
				return $http.get('http://app.poorvikamobile.com/index.php?route=feed/rest_api/userorders&user='+id);
		}
		
		obj.getorderinfo = function(id) {
				return $http.get('http://app.poorvikamobile.com/index.php?route=feed/rest_api/orders&id='+id);
		}
				
		return obj;
    }])
	
	.factory('utility', ['$http','$rootScope', function($http,$rootScope) {
		var obj={};

		obj.getlogin = function(){
			$rootScope.$broadcast('show:login');
		}
		
		obj.closelogin = function(){
			$rootScope.$broadcast('hidelogin');
		}
		

				
		return obj;
    }])
	
	.factory('productbycategory', ['$http','$rootScope', function($http,$rootScope) {
		var obj={};

		obj.productbycategory = function(categoryid) {
			return $http.get('http://app.poorvikamobile.com/index.php?route=feed/rest_api/products&category='+categoryid, {
		  cache: true
		});
		}
	

		return obj;
    }]);
	
	