<?php

		
		$data = array();
		
		$dbhost = "localhost";
		$dbuser = "dashboard";
		$dbname = "dashboard";
		$dbpass = "tien";
		
		$conn = new mysqli($dbhost,$dbuser,$dbpass,$dbname);
		
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		}
	
		$value = mysqli_query($conn,"SELECT * FROM gallery");
		
		while ($row = mysqli_fetch_array($value)) {
		$row_array['id'] = $row['id'];
		$row_array['image'] = $row['image'];

		array_push($data,$row_array);
		}

		echo json_encode($data);
   

		mysqli_close($conn);  

?>