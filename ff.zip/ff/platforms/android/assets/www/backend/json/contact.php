<?php

		
		$data = array();
		
		$dbhost = "localhost";
		$dbuser = "dashboard";
		$dbname = "dashboard";
		$dbpass = "tien";
		
		$conn = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);
		
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		}
	
		$value = mysqli_query($conn,"SELECT * FROM contacts");
		
		while ($row = mysqli_fetch_array($value)) {
		$row_array['id'] = $row['id'];
		$row_array['name'] = $row['name'];
		$row_array['phone'] = $row['phone'];
		$row_array['email'] = $row['email'];

		array_push($data,$row_array);
		}

		echo json_encode($data);
   

		mysqli_close($conn);  

?>