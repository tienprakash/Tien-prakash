<?php

	$data = array();
	
	$value = json_decode(file_get_contents('php://input'), true);
		
	$id =$value['id'];
	$name =$value['name'];
	$phone =$value['phone'];
	$email =$value['email'];

	
			
	$dbhost = "localhost";
	$dbuser = "dashboard";
	$dbname = "dashboard";
	$dbpass = "tien";

	
	$conn = mysqli_connect($dbhost,$dbuser, $dbpass, $dbname);
	   if(! $conn ) {
		   die('Could not connect: ' . mysqli_error());
		}
		
	$sql = "UPDATE contacts SET name='$name',phone='$phone',email='$email' WHERE id='$id'";



	if (mysqli_query($conn, $sql)) {
		echo "success";
	} else {
		echo "Error updating record: " . mysqli_error($conn);
	}

	mysqli_close($conn);


?>