<?php


	
	$id = json_decode(file_get_contents('php://input'), true);
	

			
			$dbhost = "localhost";
			$dbuser = "dashboard";
			$dbname = "dashboard";
			$dbpass = "tien";

            
            $conn = mysql_connect($dbhost, $dbuser, $dbpass, $dbname);
            
            if(! $conn ) {
               die('Could not connect: ' . mysql_error());
            }
            
            
            $sql = "DELETE FROM dashboard.contacts WHERE contacts.id =  '$id'" ;
          
			
            $retval = mysql_query( $sql, $conn );
            
            if(! $retval ) {
               die('Could not update data: ' . mysql_error());
            }
            echo "success";
            
            mysql_close($conn);


?>