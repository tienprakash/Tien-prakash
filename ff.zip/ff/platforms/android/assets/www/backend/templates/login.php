<?php

			$value = json_decode(file_get_contents('php://input'), true);

			
			$pass = $value['password'];

			$dbhost = 'localhost';
			$dbuser = 'dashboard';
			$dbpass = 'tien';
			
			$conn = mysql_connect($dbhost, $dbuser, $dbpass);
			if(! $conn )
			{
			  die('Could not connect: ' . mysql_error());
			}
			$sql = "SELECT * FROM users where password='$pass'";

			mysql_select_db('dashboard');
			$retval = mysql_query( $sql, $conn );
			if(! $retval )
			{
			  die('Could not get data: ' . mysql_error());
			}
			while($row = mysql_fetch_array($retval, MYSQL_ASSOC))
			{
				$password = $row['password'];
			} 
			
			if($pass === $password) 
			{
				echo "success";
			}

			mysql_close($conn);

?>