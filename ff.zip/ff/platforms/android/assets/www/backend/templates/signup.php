<?php

	
	$value = json_decode(file_get_contents('php://input'), true);
	
	print_r ($value);

	$name = $value['name'];
	$email = $value['email'];
	$pass1 = $value['password1'];
	$pass2 = $value['password2'];
	
	if($pass1 === $pass2)
	{
		$pass = $pass1;
	}
	else {
		exit;
	}


	$dbhost = "localhost";
	$dbuser = "dashboard";
	$dbname = "dashboard";
	$dbpass = "tien";
	
	$conn = new mysqli($dbhost,$dbuser,$dbpass,$dbname);
	
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}
	
	$sql = "INSERT INTO users(name,email,password) VALUES ('$name','$email','$pass')";
	
	$result = mysqli_query($conn, $sql);

	mysqli_close($conn);  

?>