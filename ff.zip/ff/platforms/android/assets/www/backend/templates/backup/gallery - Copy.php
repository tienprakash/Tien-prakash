<?php

$valid_extensions = array('jpeg', 'jpg', 'png', 'gif', 'bmp'); // valid extensions
$path = 'uploads/'; // upload directory

if($_FILES['file']['name']){


	$img = $_FILES['file']['name'];
	$tmp = $_FILES['file']['tmp_name'];
	
	print_r($img);
	
	// get uploaded file's extension
	$ext = strtolower(pathinfo($img, PATHINFO_EXTENSION));

	// can upload same image using rand function
	$final_image = $img;


	// check's valid format
	if(in_array($ext, $valid_extensions)) 
	{					
		$path = $path.strtolower($final_image);	
			
		if(move_uploaded_file($tmp,$path)) 
		{
			echo "<img src='$path' />";
		}
	} 
	else 
	{
		echo 'invalid';
	}
	
	$dbhost = "localhost";
	$dbuser = "dashboard";
	$dbname = "dashboard";
	$dbpass = "tien";
	
	$conn = new mysqli($dbhost,$dbuser,$dbpass,$dbname);
	
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}
	
	$sql = "INSERT INTO gallery(image) VALUES ('$img')";
	
	$result = mysqli_query($conn, $sql);

}


?>