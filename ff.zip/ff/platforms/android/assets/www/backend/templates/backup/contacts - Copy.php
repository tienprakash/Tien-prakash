<?php


	$data = array();
	
	$value = json_decode(file_get_contents('php://input'), true);
	
	print_r ($value);

	$name = $value['name'];
	$phone = $value['phone'];
	$email = $value['email'];


	$dbhost = "localhost";
	$dbuser = "dashboard";
	$dbname = "dashboard";
	$dbpass = "tien";
	
	$conn = new mysqli($dbhost,$dbuser,$dbpass,$dbname);
	
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}
	
	$sql = "INSERT INTO contacts(name,phone,email) VALUES ('$name','$phone','$email')";
	
	$result = mysqli_query($conn, $sql);

	mysqli_close($conn);  

?>